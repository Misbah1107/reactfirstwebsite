import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import logo1 from './media/olx.png';
import img1 from './media/image (11).webp';
import img2 from './media/image1.jpg';
import img3 from './media/olx app image.png';
import finder from './media/iconfinder.png';
import facebook from './media/download.png';
import youtube from './media/youtube.png';
import twitter from './media/twitter.png';
import instagram from './media/instagram.png';
import playstore from './media/app-store-png-logo-33115.png';

function App() {
  return (
    <div className="App">
       <nav className="navbar navbar-light bg-light ">
        <div className="container-fluid">
            <div className="d-flex justify-content-around">
                <a className="navbar-brand  " href="#">
                    <img src= {logo1} alt="" width="50" height="30" className="d-inline-block align-text-top"/>

                </a>


                <div className="input-group flex-nowrap selector-for-some-widget">
                    <span className="input-group-text bg-white" id="addon-wrapping"><img src= {finder} alt="" className="img-fluid" width="50%" /> </span>
                    <select className="form-select" size="1" aria-label="size 1 select example"
                        aria-describedby="addon-wrapping">
                        <option value="pakistan">Pakistan</option>
                        <option value="punjab">Punjab</option>
                        <option value="islamabad_capital_territory">Islambad Capital Territory</option>
                        <option value="sindh">Sindh</option>
                        <option value="khyber_pakhtunkhwa">Khyber Pakhtunkhwa</option>
                    </select>
                </div>
            </div>
            <div className="input-group flex-nowrap selector-for-some-widget">
                <input type="text" className="form-control" placeholder="Find Car,Mobile Phone and More"
                    aria-label="Find Car,Mobile Phone and More" aria-describedby="addon-wrapping"/>
                <span className="input-group-text text-light bg-dark" id="addon-wrapping"><img src= {finder} alt="" className="img-fluid" width="50%" /></span>
            </div>
            <div className="col-lg-1 col-sm-4 col-md-3 col-xs-12"><a href="#" id="login">Login</a></div>
            <div className="col-lg-1 col-sm-4 col-md-3 col-xs-12">
                <button className="button btn-light bg-white" type="button">+Sell</button>
            </div>
        </div>
    </nav>
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">

            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navba">
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#"> ALL CATEGORIES </a>
                </li>
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#"> Mobile Phone </a>
                </li>
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#">Cars</a>
                </li>
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#">Motorcycles </a>
                </li>
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#">Houses </a>
                </li>
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#">TV-Video-Audio </a>
                </li>
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#">Tablets </a>
                </li>
                <li className="nav-item">
                    <a className="nav-link active text-dark" href="#">Lands & Plots </a>
                </li>
            </div>
            </div>
    </nav>
    <div>
        <img src={img2} alt="olx" width="100%" />
    </div>


    <div className="container ">

        <div id="carouselExampleControls" className="carousel slide" data-ride="carousel">
            <div className="carousel-inner">
                <div className="carousel-item active">

                    <div className="bg">
                        <div className="row justify-content-around bg-gray mt-3">
                            <div className="based">
                                <h3>Based on your last search</h3>
                                <span><a href="#" className="text-dark">View more</a></span>
                            </div>

                            <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
                                <div className="card">
                                    <div className="card-block">
                                        <span className="featured_and_heart">
                                        <span className="featured">FEATURED</span>
                                        <i className="far fa-heart"></i>
                                        </span>
                                        <img src= {img1} alt="" className="img-fluid" width="100%" />
                                        <div className="card-title">
                                            <h3>Rs 39,999</h3>  
                                        </div>
                                        <div className="card-text">
                                            <p>Infinix Zero 8 128gb Built.</p>
                                            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
                                <div className="card">
                                    <div className="card-block">
                                        <span className="featured_and_heart">
                                        <span className="featured">FEATURED</span>
                                        <i className="far fa-heart"></i>
                                        </span>
                                        <img src={img1} alt="" className="img-fluid" width="100%" />
                                        <div className="card-title">
                                            <h3>Rs 39,999</h3>  
                                        </div>
                                        <div className="card-text">
                                            <p>Infinix Zero 8 128gb Built.</p>
                                            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
                                <div className="card">
                                    <div className="card-block">
                                        <span className="featured_and_heart">
                                        <span className="featured">FEATURED</span>
                                        <i className="far fa-heart"></i>
                                        </span>
                                        <img src={img1} alt="" className="img-fluid" width="100%" />
                                        <div className="card-title">
                                            <h3>Rs 39,999</h3>  
                                        </div>
                                        <div className="card-text">
                                            <p>Infinix Zero 8 128gb Built.</p>
                                            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
                                <div className="card">
                                    <div className="card-block">
                                        <span className="featured_and_heart">
                                        <span className="featured">FEATURED</span>
                                        <i className="far fa-heart"></i>
                                        </span>
                                        <img src={img1} alt="" className="img-fluid" width="100%" />
                                        <div className="card-title">
                                            <h3>Rs 39,999</h3>  
                                        </div>
                                        <div className="card-text">
                                            <p>Infinix Zero 8 128gb Built.</p>
                                            <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <a className="carousel-control-prev" href="#carouselExampleControls" role="button"
                                data-slide="prev">
                                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span className="sr-only">Previous</span>
                            </a>

                            <a className="carousel-control-next" href="#carouselExampleControls" role="button"
                                data-slide="next">
                                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                                <span className="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<div className="container">
    <div className="row">
        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

<div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-lg3 col-md-3 col-sm-6 p-3"  >
            <div className="card">
                <div className="card-block">
                    <span className="featured_and_heart">
                    <span className="featured">FEATURED</span>
                    <i className="far fa-heart"></i>
                    </span>
                    <img src={img1} alt="" className="img-fluid" width="100%" />
                    <div className="card-title">
                        <h3>Rs 39,999</h3>  
                    </div>
                    <div className="card-text">
                        <p>Infinix Zero 8 128gb Built.</p>
                        <p className="carddate">karachi,<span id="cardespan"> 20-12-2020</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div className="btn">
        <button type="button" className="btn btn-outline-dark">Lord more</button>
    </div>
    <div className="olxapp">
        <img width="100%" src={img3} alt="olx" height="200px" />
    </div>

    <footer>
        <div className="container-fluid bg-light text-light  ">
            <div className="row">
                <div className="col-md-2 col-sm-3 col-xs-12">
                    <ul>
                        <h6 className="text-dark">POPULAR CATEGORIES</h6>
                        <li className="footer_li"><a href="#">Cars</a></li>
                        <li className="footer_li"><a href="#">Flats for rent</a></li>
                        <li className="footer_li"><a href="#">Jobs</a></li>
                        <li className="footer_li"><a href="#">Mobile Phones</a></li>
                    </ul>
                </div>
                <div className="col-md-2 col-sm-3 col-xs-12">
                    <ul>
                        <h6 className="text-dark">TRENDING SEARCHES</h6>
                        <li className="footer_li"><a href="#">Bikes</a></li>
                        <li className="footer_li"><a href="#">Watches</a></li>
                        <li className="footer_li"><a href="#">Books</a></li>
                        <li className="footer_li"><a href="#">Dogs</a></li>
                    </ul>
                </div>
                <div className="col-md-2 col-sm-3 col-xs-12">
                    <ul>
                        <h6 className="text-dark">ABOUT US</h6>
                        <li className="footer_li"><a href="#">About OLX Group</a></li>
                        <li className="footer_li"><a href="#">OLX Blog</a></li>
                        <li className="footer_li"><a href="#">Contact Us</a></li>
                        <li className="footer_li"><a href="#">OLX for Businesses </a></li>
                    </ul>
                </div>
                 <div className="col-md-2 col-sm-3 col-xs-12">
                    <ul>
                        <h6 className="text-dark">OLX</h6>
                        <li className="footer_li"><a href="#">Help</a></li>
                        <li className="footer_li"><a href="#">Sitemap</a></li>
                        <li className="footer_li"><a href="#">Legal & Privacy information</a></li>
                        <li className="footer_li"><a href="#"></a></li>
                    </ul>
                </div>
                <div className="col-md-2 col-sm-3 col-xs-12">
                    <ul className="followus">
                        <h6 className="text-dark">Follow Us</h6>
                        <li><a href="https://www.facebook.com"><img src={facebook} alt="facebook"
                                    width="30px" /></a></li>
                        <li><a href="https://twitter.com"><img src={twitter} alt="twitter"
                                    width="30px" /></a></li>
                        <li><a href="https://www.youtube.com"><img
                                    src={youtube}
                                    alt="youtube" width="30px" /></a></li>
                        <li><a href="https://www.instagram.com"><img
                                    src={instagram}
                                    alt="instagram" width="30px" /></a></li><br /><br />
                        <a href="#"><img src={playstore} alt="play_&_applestor"
                                width="100%" /></a>
                    </ul>
                </div> 
                </div>
                 
            </div>
            <div className="greenline ">
                <p className="text1">Other Countries India - South Africa - Indonesia</p>
                <p className="text2">Free classNameifieds in Pakistan. © 2006-2021 OLX</p>
            </div>
    </footer>

    </div>
  );
}

export default App;
